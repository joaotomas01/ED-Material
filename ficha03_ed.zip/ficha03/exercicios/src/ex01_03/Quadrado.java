package ex01_03;

public class Quadrado extends Rectangulo {
    public Quadrado(int side) {
        super(side, side);
    }
}
